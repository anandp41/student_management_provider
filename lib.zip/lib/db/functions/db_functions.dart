import 'dart:convert';

import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sql/db/model/data_model.dart';
import 'package:flutter/material.dart';
import 'dart:io' as io;

ValueNotifier<List<StudentModel>> studentListNotifier = ValueNotifier([]);
late Database _db;

Future<void> initializeDataBase() async {
  io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
  String path = join(documentsDirectory.path, 'student.db');
  _db = await openDatabase(
    path,
    version: 1,
    onCreate: (Database db, int version) async {
      await db.execute(
          'CREATE TABLE student (admno TEXT PRIMARY KEY,name TEXT,age TEXT,class TEXT,image TEXT)');
      print('table created now');
    },
  );
  getAllStudents();
}

//Alter table function definition
Future<dynamic> alterTable(String TableName, String ColumnName) async {
  var dbClient = await _db;
  var count = await dbClient
      .execute("ALTER TABLE $TableName ADD COLUMN $ColumnName TEXT;");

  print(await dbClient.query('student'));

  return count;
}
// Future<void> makeDB() async {
//   _db.execute(
//       'CREATE TABLE student (admno TEXT PRIMARY KEY,name TEXT,age TEXT,class TEXT)');
// }

Future<void> addStudent(StudentModel value) async {
  _db.rawInsert(
      'INSERT INTO student (admno,name,age,class,image) VALUES (?,?,?,?,?)', [
    value.admno,
    value.name.toUpperCase(),
    value.age,
    value.classInSchool,
    value.image64bit
  ]);
  print('add ${value.image64bit}');
  await getAllStudents();
  // studentListNotifier.value.add(value);
}

Future<void> getAllStudents() async {
  final _values = await _db.rawQuery('SELECT * FROM student');
  print('getAllstudents-start  $_values');

  studentListNotifier.value.clear();
  studentListNotifier.notifyListeners();
  _values.forEach((map) {
    final student = StudentModel.fromMap(map);
    print('getAllstudents-end ${student.admno} ${student.image64bit}');
    studentListNotifier.value.add(student);
    studentListNotifier.notifyListeners();
  });
}

Future<StudentModel> getThisStudent(String admno) async {
  StudentModel? student;
  final result =
      await _db.rawQuery('SELECT * FROM student WHERE admno=?', [admno]);
  result.forEach((map) {
    student = StudentModel.fromMap(map);
  });
  return student!;
}
// Future<void> dropTable() async {
//   // Run the DROP TABLE statement
//   await _db.execute('DROP TABLE IF EXISTS student');
// }

Future<void> deleteRow(BuildContext catx, String admno) async {
  return showDialog(
      context: catx,
      builder: (ctx1) {
        return AlertDialog(
            title: Text('Delete'),
            content: Text("Are you sure to delete?"),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () async {
                      await _db.rawDelete(
                          'DELETE from student where admno=?', [admno]);
                      getAllStudents();
                      Navigator.pop(catx);
                    },
                    icon: Icon(
                      Icons.check,
                    ),
                    label: Text('Yes'),
                  ),
                  ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(catx);
                      },
                      icon: Icon(Icons.cancel),
                      label: Text('No'))
                ],
              ),
            ]);
      });
}

Future<void> updateField(
    {required String admno,
    required String name,
    required String age,
    required String classInSchool,
    required String? image64bit}) async {
  var count = await _db.rawUpdate(
      'UPDATE student SET name=?,age=?,class=?,image=? WHERE admno=$admno',
      [name.toUpperCase(), age, classInSchool, image64bit]);
  await getAllStudents();
  print('$count row(s) updated');
}

Future<dynamic> pickImage() async {
  var image = await ImagePicker()
      .pickImage(source: ImageSource.gallery, imageQuality: 45);

  if (image != null) {
    var imageBytes = await image.readAsBytes();

    print("IMAGE PICKED: ${image.path}");

    String base64Image = base64Encode(imageBytes);

    return base64Image;
  }
}
